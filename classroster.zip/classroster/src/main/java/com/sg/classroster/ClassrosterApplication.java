package com.sg.classroster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassrosterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassrosterApplication.class, args);
	}

}
