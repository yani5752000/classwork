import React from 'react';

function DeleteModal (){
  return <h1>Delete Modal</h1>
}

export default DeleteModal